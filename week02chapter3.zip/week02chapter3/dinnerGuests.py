#3-9. Dinner Guests: Working with one of the programs from Exercises 3-4 through 3-7 (page 42), use len() to print a message indicating the number of people you are inviting to dinner.

guestList = ['Loydene McWaters', 'Lynn Adams', 'Jaime Buckner']

print(f"You are invited to my dinner {guestList[0]}!")
print(f"You are invited to my dinner {guestList[1]}!")
print(f"You are invited to my dinner {guestList[2]}!")

guestList = ['Loydene McWaters', 'Lynn Adams', 'Jaime Buckner']
len(guestList)


