# 4-1.Pizzas: Think of at least three kinds of your favorite pizza. 
# Store these pizza names in a list, and then use a for loop to print the name of each pizza.
# Print a sentence about each pizza.
# Add a line at the end of your program, outside the for loop, that states how much you like pizza.

yummy_pizzas = ['cheese', 'bean', 'round']

for pizza in yummy_pizzas:
    print(pizza)

print("\n")


for pizza in yummy_pizzas:
    print("I really enjoy " + pizza + " pizza!")


print("\nI really admire pizza!")