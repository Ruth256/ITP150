# Instead of one million, try a thousand first then add to the file to do a million.  Keep both versions of the code in your file.
# 4-4. One Million: Make a list of the numbers from one to one million, and then use a for loop to print the numbers. 
# (If the output is taking too long, stop it by pressing CTRL-C or by closing the output window.)


numbers = list(range(1, 1001))
for number in numbers:
    print(number)



numbers = list(range(1, 1000001))
for number in numbers:
    print(number)



