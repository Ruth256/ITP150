# 4-3. Counting to Twenty: Use a for loop to print the numbers from 1 to 20, inclusive. 

numbers = list(range(1, 21))

for number in numbers:
    print(number)