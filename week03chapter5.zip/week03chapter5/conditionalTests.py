#5-1. Conditional Tests: Write a series of conditional tests. 
#Print a statement describing each test and your prediction for the results of each test. 
#Your code should look something like this:

#car = 'subaru'
#print("Is car == 'subaru'? I predict True.")
#print(car == 'subaru')

#print("\nIs car == 'audi'? I predict False.")
#print(car == 'audi')

#Look closely at your results, and make sure you understand why each line evaluates to True or False.
# Create at least ten tests. 
# Have at least five tests evaluate to True and another five tests evaluate to False.

#1 True
food = 'lemon'
print("Is food == 'lemon'? I predict True.")
print(food == 'lemon')
#2 False
print("\nIs food == 'lime'? I predict False.")
print(food == 'lime')
#3 True
dog = 'collie'
print("Is that dog == 'collie'? I predict True.")
print(dog == 'collie')
#4 False
dog = 'collie'
print("\nIs that dog == 'dalmation'? I predict False.")
print(dog == 'dalmation')
#5 False
name = 'Joe'
name.upper() == 'joe'
print("Is the name == 'joe'? I predict True.")
print(name == 'joe')
#6 True
name = 'Joe'
name.upper() == 'joe'
print("Is the name == 'joe'? I predict True.")
print(name == 'Joe')
#7 True
color = 'pink'
color == 'pink'
print("The color is == 'pink'? I predict True.")
print(color == 'pink')
#8 False
color = 'purple'
color == 'pink'
print("The color is not == 'pink? I predict True.")
print(color == 'pink')
#9 True
plant = 'fern'
print("Is plant == 'fern'? I predict True.")
print(plant == 'fern')
#10 False
print("\nIs plant == 'fern'? I predict False.")
print(plant == 'succulent')







