#Lisa Adams 
#ITP 150
#09/06/2023

#Message Output 1: ITP 150 is Great! Message Output 2: ITP 150 is AWESOME!
myMessage = "ITP 150 is Great!"
print(myMessage)

myMessage = "ITP 150 is AWESOME!"
print(myMessage)