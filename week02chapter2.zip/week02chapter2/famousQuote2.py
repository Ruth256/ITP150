#Lisa Adams 
#ITP 150
#09/06/2023

#2-6. Famous Quote 2: Repeat Exercise 2-5, but this time, represent the famous person’s name using a variable called famous_person. Then compose your message and represent it with a new variable called message. Print your message.

famous_person = 'Tim Robinson'
myMessage = " 'Or what about a thousand plastic meatballs!' "


print(myMessage,f"{famous_person}")