#Lisa Adams 
#ITP 150
#09/06/2023

#Output: Hello Python, today's weather is sunny and hot.
personsName = "Python"

print(f"Hello, {personsName}, today's weather is sunny and hot.")