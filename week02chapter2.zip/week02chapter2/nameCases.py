#Lisa Adams 
#ITP 150
#09/06/2023

#Use your name in this assignment.

personsName = "Lisa Adams"

#persons name in lowercase
print("lisa adams")

#persons name in uppercase
print("LISA ADAMS")

#persons name in titlecase
print("Lisa Adams")