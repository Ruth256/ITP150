#Lisa Adams 
#ITP 150
#09/06/2023


#I was confused on what it was asking

favorite_number = 7
print(favorite_number)
message = "My favorite number is 7"
print(message)
print(6+1)




