#Lisa Adams 
#ITP 150
#09/06/2023

#Don't use the quote from Einstein that the textbook uses.
#2-5. Famous Quote: Find a quote from a famous person you admire. Print the quote and the name of its author. 

#“Or what about a thousand plastic meatballs!” Tim Robinson


print(" 'Or what about a thousand plastic meatballs!' Tim Robinson ")