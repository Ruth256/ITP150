#Lisa Adams 
#ITP 150
#09/06/2023

#2-8. Number Eight: Write addition, subtraction, multiplication, and division operations that each result in the number 8. Be sure to enclose your operations in print() calls to see the results. You should create four lines that look like this:
#Use 12 instead
print(11+1)
print(13-1)
print(4*3)
print(24/2)